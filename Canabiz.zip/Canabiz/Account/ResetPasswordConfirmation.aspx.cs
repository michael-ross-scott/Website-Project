﻿using System.Web.UI;

namespace Canabiz.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}